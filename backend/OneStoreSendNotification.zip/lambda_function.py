# import boto3
# import json

# SNS = boto3.client('sns')
# TOPIC_ARN = 'arn:aws:sns:us-east-1:282571451626:UserRegistration'

# def lambda_handler(event, context):
#     try:
#         # Extract user email from the event
#         data = json.loads(event['body'])
#         user_email = data['email']
        
#         # user_email = event['email']
        
#         filter_policy = {
#             "email": [user_email]
#         }
#         # Subscribe the email to the SNS topic
#         SNS.subscribe(
#             TopicArn=TOPIC_ARN,
#             Protocol='email',
#             Endpoint=user_email,
#             Attributes = {
#                 'FilterPolicy' : json.dumps(filter_policy)
#             }
#         )
#         return event
#         # return {
#         #     'statusCode': 200,
#         #     'body': json.dumps({
#         #         'message': 'Subscription created successfully',
#         #     })
#         # }
#     except Exception as e:
#         return {
#             'statusCode': 500,
#             'body': json.dumps({'message': 'Error sending notification', 'error': str(e)})
#         }



import json
import boto3
import os

SNS = boto3.client('sns')
# TOPIC_ARN = 'arn:aws:sns:us-east-1:282571451626:UserRegistration'
TOPIC_ARN = os.environ['TOPIC_ARN']


def lambda_handler(event, context):
    try:
        # Extract the user email from the event
        user_email = event['request']['userAttributes']['email']
        print(user_email);
        
        # Compose the filter policy for subscription
        filter_policy = {
            "email": [user_email]
        }
        
        # Subscribe the email to the SNS topic
        response = SNS.subscribe(
            TopicArn=TOPIC_ARN,
            Protocol='email',
            Endpoint=user_email,
            Attributes={
                'FilterPolicy': json.dumps(filter_policy)
            }
        )
        
        print(f"Successfully subscribed {user_email} to SNS topic.")
        
        return event  # Must return the event for Cognito to process it correctly
        
    except Exception as e:
        print(f"Error subscribing {user_email} to SNS topic: {str(e)}")
        raise e  # Raising the error will allow you to debug the issue better
