import json
import boto3
from urllib.parse import urlparse, parse_qs
import os

S3 = boto3.client('s3')

def lambda_handler(event, context):
    try:
        # data = json.loads(event['body'])
        # print("data received in lambda", data);
        # user_id = data['userId']
        # file_key = data['file_key']
        # bucket_name='onestore'
        
        print("data received in lambda", event);
        user_id = event['userId']
        file_key = event['file_key']
        # bucket_name='testdemo-onestore'
        bucket_name = os.environ['BUCKET_NAME']
       

        # Delete the file from the S3 bucket
        S3.delete_object(Bucket=bucket_name, Key=file_key)
        
        return {
            'statusCode': 200,
            'headers': {
                'Content-Type': 'application/json',
                'Access-Control-Allow-Origin': '*',  # Allow all origins
                'Access-Control-Allow-Methods': 'DELETE,OPTIONS',
                'Access-Control-Allow-Headers': 'Content-Type'
            },
            'body': json.dumps({'message': 'File deleted successfully'})
        }
    except Exception as e:
        print(e)
        return {
            'statusCode': 500,
            'headers': {
                'Content-Type': 'application/json',
                'Access-Control-Allow-Origin': '*',  # Allow all origins
                'Access-Control-Allow-Methods': 'DELETE,OPTIONS',
                'Access-Control-Allow-Headers': 'Content-Type'
            },
            'body': json.dumps({'message': 'Error deleting file', 'error': str(e)})
        }
