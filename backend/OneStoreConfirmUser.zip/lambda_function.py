import json
import boto3
from botocore.exceptions import ClientError

def lambda_handler(event, context):
    # Get the username and userPoolId from the event
    username = event.get('username')
    user_pool_id = event.get('userPoolId')

    # Check if username and userPoolId are provided
    if not username or not user_pool_id:
        return {
            'statusCode': 400,
            'body': json.dumps({'message': 'Username and User Pool ID are required.'})
        }

    # Create a new Cognito Identity Provider client
    client = boto3.client('cognito-idp', region_name='us-east-1')

    try:
        # Confirm the user signup
        response = client.admin_confirm_sign_up(
            UserPoolId=user_pool_id,
            Username=username
        )

        return {
            'statusCode': 200,
            'body': json.dumps({'message': 'User confirmed successfully.'})
        }
    except ClientError as e:
        return {
            'statusCode': 500,
            'body': json.dumps({'message': 'Error confirming user.', 'error': str(e)})
        }

