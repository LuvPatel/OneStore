# import json
# import boto3

# SNS = boto3.client('sns')
# TOPIC_ARN = 'arn:aws:sns:us-east-1:282571451626:UserRegistration'
# def lambda_handler(event, context):
    
#     user_email = event['email'];
#     print("user_email", user_email);
#     # Compose the email message
#     email_subject = 'Welcome to OneDrive'
#     email_message = f'The file has been uploaded successfully!!, {user_email}!'
        
#     # Publish the message to the SNS topic
#     response = SNS.publish(
#         TopicArn=TOPIC_ARN,
#         Message=email_message,
#         Subject=email_subject,
#         MessageAttributes={
#             'email': {
#                 'DataType': 'String',
#                 'StringValue': user_email
#             }
#         }
#     )
    
#     return {
#         'statusCode': 200,
#         'body': json.dumps('Message sent to user successfully!!')
#     }



import json
import boto3
import os

SNS = boto3.client('sns')
# TOPIC_ARN = 'arn:aws:sns:us-east-1:282571451626:UserRegistration'
TOPIC_ARN = os.environ['TOPIC_ARN']

def lambda_handler(event, context):
    print("event obained in notification lambda ", event);
    try:
        # Extract the user email from the event
        user_email = event['email']
        print("user_email:", user_email)
        
        # Compose the email message
        email_subject = 'Welcome to OneDrive'
        email_message = f'The file has been uploaded successfully!!, {user_email}!'
        
        # Publish the message to the SNS topic
        response = SNS.publish(
            TopicArn=TOPIC_ARN,
            Message=email_message,
            Subject=email_subject,
            MessageAttributes={
                'email': {
                    'DataType': 'String',
                    'StringValue': user_email
                }
            }
        )
        
        print("SNS publish response:", response)
        
        return {
            'statusCode': 200,
            'body': json.dumps('Message sent to user successfully!!')
        }
    
    except Exception as e:
        print(f"Error sending message: {str(e)}")
        return {
            'statusCode': 500,
            'body': json.dumps(f'Error sending message: {str(e)}')
        }
