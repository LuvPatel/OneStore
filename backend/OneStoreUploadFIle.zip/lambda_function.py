import json
import boto3
import base64
import uuid
import os

S3 = boto3.client('s3')
dynamoDb = boto3.client('dynamodb')

def lambda_handler(event, context):
    print("lambda_event_data", event);
    # data = json.loads(event);
    # data = json.loads(event['body'])
    file_to_be_uploaded =  base64.b64decode(event['fileContent'])
    fileName = event['fileName']
    user_id = event['userId']
    fileid = str(uuid.uuid4())
    # s3_key = f"{fileid}_{fileName}"
    s3_key = f"user-{user_id}/{fileid}_{fileName}"
    bucketName = os.environ['BUCKET_NAME']
    
    # S3.put_object(BucketName,Key = s3_key, Body = file_to_be_uploaded)
    S3.put_object(Bucket=bucketName, Key=s3_key,Body = file_to_be_uploaded)
    # return {
    #     'statusCode': 200,
    #     'body': json.dumps({'filename' : fileName})
    # }
    return {
        'statusCode': 200,
        'headers': {
            'Content-Type': 'application/json',
             'Access-Control-Allow-Origin': '*',
             'Access-Control-Allow-Headers': 'Content-Type',
             'Access-Control-Allow-Methods': 'OPTIONS,POST,GET'
        },
        'body': json.dumps({'filename': fileName})
    }