# import json
# import boto3

# S3 = boto3.client('s3')

# def lambda_handler(event, context):
#     print("Received event: " + json.dumps(event, indent=2))
#     user_id = event['queryStringParameters']['userId']
#     bucket_name = 'onestore'
#     prefix = f"user-{user_id}/"
    
#     response = S3.list_objects_v2(
#         Bucket=bucket_name,
#         Prefix=prefix
#     )
    
#     files = []
#     if 'Contents' in response:
#         for item in response['Contents']:
#             file_key = item['Key']
#             presigned_url = S3.generate_presigned_url('get_object', Params={
#                 'Bucket': bucket_name,
#                 'Key': file_key
#             }, ExpiresIn=3600)
#             # files.append({
#             #     'fileName': file_key.split('/')[-1],
#             #     'url': presigned_url,
#             #     'file_key' : file_key
#             # })
#             files.append({
#                 'fileName': file_key.split('_')[-1],
#                 'url': presigned_url,
#                 'file_key' : file_key
#             })
    
#     return {
#         'statusCode': 200,
#         'body': json.dumps(files)
#     }



import json
import boto3
import os

S3 = boto3.client('s3')

def lambda_handler(event, context):
    print("Received event: " + json.dumps(event, indent=2))
    
    # Extract user_id from query parameters
    user_id = event['queryStringParameters'].get('userId', None)
    
    if not user_id:
        return {
            'statusCode': 400,
            'body': json.dumps({'error': 'Missing userId parameter'})
        }

    # bucket_name = 'onestore'
    # bucket_name = 'testdemo-onestore'
    bucket_name = os.environ['BUCKET_NAME']
    prefix = f"user-{user_id}/"
    
    try:
        # List objects with the specified prefix
        response = S3.list_objects_v2(Bucket=bucket_name, Prefix=prefix)
        
        files = []
        if 'Contents' in response:
            for item in response['Contents']:
                file_key = item['Key']
                presigned_url = S3.generate_presigned_url('get_object', Params={
                    'Bucket': bucket_name,
                    'Key': file_key
                }, ExpiresIn=3600)
                files.append({
                    'fileName': file_key.split('_')[-1],
                    'url': presigned_url,
                    'file_key': file_key
                })

        return {
            'statusCode': 200,
            'body': json.dumps(files),  # Directly return JSON array of files
            'headers': {
                'Content-Type': 'application/json'  # Set content type to JSON
            }
        }
    except Exception as e:
        print(f"Error: {e}")
        return {
            'statusCode': 500,
            'body': json.dumps({'error': 'Internal Server Error'})
        }
